#!/bin/bash
## This is to run the first program main.cpp
./code4
